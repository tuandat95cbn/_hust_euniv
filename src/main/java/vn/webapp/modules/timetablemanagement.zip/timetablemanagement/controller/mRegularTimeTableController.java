package vn.webapp.modules.timetablemanagement.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import vn.webapp.modules.timetablemanagement.service.mRegularCourseTimeTableEntryService;
import vn.webapp.modules.timetablemanagement.service.mRegularCourseTimeTableService;

@Controller("cpmRegularTimeTable")
@RequestMapping(value={"/cp"})
public class mRegularTimeTableController {
	@Autowired
	mRegularCourseTimeTableService regularCourseTimeTableService;
	@Autowired
	mRegularCourseTimeTableEntryService regularCourseTimeTableEntryService;
	public String name (){
		return "mRegularTimeTableController: ";
	}
	@RequestMapping(value="/view-regular-timetale.html", method= RequestMethod.GET )
	public String viewRegularExamTimetable(ModelMap model, HttpSession session){
		//List< > list = regularCourseTimeTableService.getAllCourseTimeTable() ;
		System.out.println("This is "+name());
		regularCourseTimeTableService.saveARegularCourseTimeTable("1", "1", 1, "1","1","1");
		regularCourseTimeTableEntryService.saveARegularCourseTimeTableEntry("1", 1, "1", "1","1","1","1");
		System.out.println("This is 2 "+name());
		model.put("regularCourseTimeTable", regularCourseTimeTableService.getAllCourseTimeTable());
		
		return "cp.ViewRegularTimeTable";
	}
	
	@RequestMapping(value="/view-regular-timetale-entry.html", method= RequestMethod.GET )
	public String viewRegularExamTimetableEntry(ModelMap model, HttpSession session){
		//List< > list = regularCourseTimeTableService.getAllCourseTimeTable() ;
		model.put("regularCourseTimeTableEntry", regularCourseTimeTableEntryService.getAllRegularCourseTimeTableEntry());
		
		return "cp.ViewRegularTimeTableEntry";
	}
}
