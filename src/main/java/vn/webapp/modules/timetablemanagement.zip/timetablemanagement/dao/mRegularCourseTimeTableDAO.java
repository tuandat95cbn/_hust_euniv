package vn.webapp.modules.timetablemanagement.dao;

import java.util.List;

import vn.webapp.modules.timetablemanagement.model.mRegularCourseTimeTable;
import vn.webapp.modules.usermanagement.model.mStaff;

public interface mRegularCourseTimeTableDAO {
	public List<mRegularCourseTimeTable > getAllCourseTimeTable();
	public int saveARegularCourseTimeTable(mRegularCourseTimeTable rctt);
}
