package vn.webapp.modules.timetablemanagement.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import vn.webapp.dao.BaseDao;
import vn.webapp.modules.timetablemanagement.model.mRegularCourseTimeTable;
@Repository
@SuppressWarnings({"unchecked", "rawtypes"})
public class mRegularCourseTimeTableDAOImpl extends BaseDao implements mRegularCourseTimeTableDAO{
	@Autowired
	private SessionFactory sessionFactory;
	public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
	@Override
	public List<mRegularCourseTimeTable> getAllCourseTimeTable() {
		// TODO Auto-generated method stub
		try{
		begin();
		Criteria criteria= getSession().createCriteria(mRegularCourseTimeTable.class);
		List <mRegularCourseTimeTable> listRegularCourseTimeTable = criteria.list();
		commit();
		return listRegularCourseTimeTable;
		} catch (HibernateException e){
			e.printStackTrace();
			rollback();
			close();
			return null;
		} finally {
			flush();
			close();
		}
	}
	@Override
	public int saveARegularCourseTimeTable(mRegularCourseTimeTable rctt) {
		// TODO Auto-generated method stub
		System.out.println("This is "+name());
		System.out.println("rctt is: "+rctt.toString());
		try {
            begin();
            System.out.println("This is 2"+name());
            int id = 0; 
            getSession().save(rctt);
            System.out.println("This is 3"+name());
            commit();
            System.out.println("This is 4"+name());
            return id;           
         } catch (HibernateException e) {
             e.printStackTrace();
             rollback();
             close();
             return 0;
         } finally {
             flush();
             close();
         }
	}
	
	public String name(){
		return "mRegularCourseTimeTableDAOImpl";
	}

}
