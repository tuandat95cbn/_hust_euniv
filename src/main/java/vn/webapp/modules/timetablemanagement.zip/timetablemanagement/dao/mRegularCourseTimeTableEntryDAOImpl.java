package vn.webapp.modules.timetablemanagement.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import vn.webapp.dao.BaseDao;
import vn.webapp.modules.timetablemanagement.model.mRegularCourseTimeTable;
import vn.webapp.modules.timetablemanagement.model.mRegularCourseTimeTableEntry;
@Repository
public class mRegularCourseTimeTableEntryDAOImpl extends BaseDao implements mRegularCourseTimeTableEntryDAO{
	@Autowired
	private SessionFactory sessionFactory;
	public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
	@Override
	public List<mRegularCourseTimeTableEntry>  getAllCourseTimeTableEntry() {
		// TODO Auto-generated method stub
		try{
		begin();
		Criteria criteria= getSession().createCriteria(mRegularCourseTimeTableEntry.class);
		List <mRegularCourseTimeTableEntry> listRegularCourseTimeTableEntry = criteria.list();
		commit();
		return listRegularCourseTimeTableEntry;
		} catch (HibernateException e){
			e.printStackTrace();
			rollback();
			close();
			return null;
		} finally {
			flush();
			close();
		}
	}
	@Override
	public int saveARegularCourseTimeTableEntry(mRegularCourseTimeTableEntry rctte) {
		// TODO Auto-generated method stub
		try {
            begin();
            int id = 0; 
            getSession().save(rctte);
            commit();
            return id;           
         } catch (HibernateException e) {
             e.printStackTrace();
             rollback();
             close();
             return 0;
         } finally {
             flush();
             close();
         }
		
	}
	
	
}
