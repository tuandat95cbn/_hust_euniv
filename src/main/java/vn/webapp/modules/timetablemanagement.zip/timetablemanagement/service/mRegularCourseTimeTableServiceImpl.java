package vn.webapp.modules.timetablemanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import vn.webapp.modules.timetablemanagement.dao.mRegularCourseTimeTableDAO;
import vn.webapp.modules.timetablemanagement.model.mRegularCourseTimeTable;
@Service
public class mRegularCourseTimeTableServiceImpl implements mRegularCourseTimeTableService {
	@Autowired
	mRegularCourseTimeTableDAO dao;
	@Override
	public List<mRegularCourseTimeTable> getAllCourseTimeTable() {
		// TODO Auto-generated method stub
		return dao.getAllCourseTimeTable();
		
	}
	@Override
	public int saveARegularCourseTimeTable(String RCTT_RCTTE_Code, String RCTT_Code, int RCTT_Day,
			String RCTT_Slots, String RCTT_Weeks, String RCTT_Room_Code) {
		// TODO Auto-generated method stub
		System.out.println("This is "+name());
		mRegularCourseTimeTable regularCourseTimeTable= new mRegularCourseTimeTable();
		System.out.println("This is 2"+name());
		regularCourseTimeTable.setRCTT_Code(RCTT_Code);
		regularCourseTimeTable.setRCTT_Day(RCTT_Day);
		regularCourseTimeTable.setRCTT_RCTTE_Code(RCTT_RCTTE_Code);
		regularCourseTimeTable.setRCTT_Room_Code(RCTT_Room_Code);
		regularCourseTimeTable.setRCTT_Slots(RCTT_Slots);
		regularCourseTimeTable.setRCTT_Weeks(RCTT_Weeks);
		System.out.println("This is 3"+name());
		return dao.saveARegularCourseTimeTable(regularCourseTimeTable);
	}
	public String name(){
		return "mRegularCourseTimeTableServiceImpl";
	}

}
